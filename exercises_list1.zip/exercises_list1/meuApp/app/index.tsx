import Onze from "../screens/Onze";
export default function App() {
  return <Onze />;
}
